public class Main {
    public static void main(String args[]) {
       String[][] data = new String[2][5];
       System.out.println("Dimension 1: " + data.length);
       System.out.println("Dimension 2: " + data[0].length);
    }
 }