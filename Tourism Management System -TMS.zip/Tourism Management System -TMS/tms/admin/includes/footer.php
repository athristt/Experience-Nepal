<div class="copyrights">
	 <p>© BIT L6  <a href="#">TMS</a> </p>
</div>	
